<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <a href="#" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                
                <a href="#" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; YouTube </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true">&nbsp; Instagram </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-map-marker" aria-hidden="true">&nbsp; Encuentranos </i>
                </a>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer">¿Porque elegirnos?</h4>
                <p> 
                    Somos una empresa de prductos de calidad y al mejor precio del mercado</br>
                    con ofertas muy buenas,atencion al cliente casi inmediata, <br>
                    tambien contamos con envios gratis dentro de la zona central.
                    
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer" >Direccion</h4>
                <p style="color: #FFF">Calle principal Texistepeque,Santa Ana, junto al mercado municipal </p>
                <p style="color: #FFF">EL Salvador</p>
                <p style="font-size:20px" aria-hidden="true">  2470-0921</p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  6067-6351</p> <a href="#" target="_blank" style="color: #5bc0de">envianos_un_mensaje</a></br>
                E-mail: <a href="#" target="_blank" style="color: #5bc0de"> &nbsp; Gomezfashion@gmail.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">GOMEZ FASHION &copy; 2022</h5>
</footer>
