[
	{
		"precio": 150,
		"id": 1,
		"title": "Fideos",
		"thumbnailUrl": "imgs/fideos.jpg"
	},

	{
		"precio": 100,
		"id": 2,
		"title": "Pan",
		"thumbnailUrl": "imgs/pan.jpeg"
	},

	{
		"precio": 200,
		"id": 3,
		"title": "Salsa",
		"thumbnailUrl": "imgs/salsa.jpeg"
	},

	{
		"precio": 450,
		"id": 4,
		"title": "Ñoquis",
		"thumbnailUrl": "imgs/ñoquis.jpeg"
	}
]