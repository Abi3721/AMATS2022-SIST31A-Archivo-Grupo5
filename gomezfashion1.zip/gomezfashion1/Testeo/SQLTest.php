<?php
include 'library/configServer.php';
include 'library/consulSQL.php';

use PHPUnit\Framework\TestCase;


final class SQLTest extends TestCase
{
    public function testConsulta()
    {
        $consulta= ejecutarSQL::consultar("SELECT * FROM producto WHERE Stock > 0 AND Estado='Activo' ORDER BY id");
        $totalproductos = mysqli_num_rows($consulta);
        $this->assertEquals(0, $totalproductos);
    }

    public function testInsertarCategoria()
    {
        $codeCateg=1;
        $nameCateg="Categoria 1";
        $descripCateg="Descripcion de la categoria 1";
        $consulta= consultasSQL::InsertSQL("categoria", "CodigoCat, Nombre, Descripcion", "'$codeCateg','$nameCateg','$descripCateg'");
        $this->assertEquals(true, $consulta);
        $consulta= consultasSQL::DeleteSQL("categoria", "CodigoCat='$codeCateg'");
        $this->assertEquals(true, $consulta);
    }

    public function testBorrarCategoria()
    {
        $codeCateg=10000000;
        $nameCateg="Categoria 10000000";
        $descripCateg="Descripcion de la categoria 10000000";
        $consulta= consultasSQL::InsertSQL("categoria", "CodigoCat, Nombre, Descripcion", "'$codeCateg','$nameCateg','$descripCateg'");
        $this->assertEquals(true, $consulta);
        $consulta= consultasSQL::DeleteSQL("categoria", "CodigoCat='$codeCateg'");
        $this->assertEquals(true, $consulta);
    }

    public function testUpdateCategoria()
    {
        $codeCateg=99999;
        $nameCateg="Categoria 1";
        $descripCateg="Descripcion de la categoria 1";
        $consulta= consultasSQL::InsertSQL("categoria", "CodigoCat, Nombre, Descripcion", "'$codeCateg','$nameCateg','$descripCateg'");
        $this->assertEquals(true, $consulta);
        $consulta= consultasSQL::UpdateSQL("categoria", "Nombre='Categoria 1 Modificada'", "CodigoCat='$codeCateg'");
        $this->assertEquals(true, $consulta);
        $consulta= consultasSQL::DeleteSQL("categoria", "CodigoCat='$codeCateg'");
        $this->assertEquals(true, $consulta);
    }

    public function testSelectConDatos()
    {
        $codeCateg=1;
        $nameCateg="Categoria 1";
        $descripCateg="Descripcion de la categoria 1";
        $consulta= consultasSQL::InsertSQL("categoria", "CodigoCat, Nombre, Descripcion", "'$codeCateg','$nameCateg','$descripCateg'");
        $this->assertEquals(true, $consulta);
        $consulta= ejecutarSQL::consultar("SELECT * FROM categoria");
        $totalproductos = mysqli_num_rows($consulta);
        $this->assertEquals(1, $totalproductos);
        $consulta= consultasSQL::DeleteSQL("categoria", "CodigoCat='$codeCateg'");
        $this->assertEquals(true, $consulta);
    }
}
?>